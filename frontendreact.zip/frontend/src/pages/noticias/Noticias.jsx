import React from "react";
import Footer from '../../common/Footer';

const Noticias = () => {
   
    return (
        <div>
      <h2>Noticias</h2>
      <br></br>
    <p> En esta seccion encontrara noticias sobre el mercado asegurador, asi como articulos y noticias de interes.</p>
            <ul>
            <li><a href="https://www.bbc.com/mundo/noticias-38973945">Historia del Seguro</a></li>
            <li><a href="https://www.lavanguardia.com/seguros/20210102/6161632/5-riesgos-seguro-ve-2021.html">Riesgos del Seguro en el 2021</a></li>
            <li><a href="https://www.willistowerswatson.com/es-AR/Solutions/credit-political-risk-and-terrorism">Soluciones nuevos Riesgos</a></li>
        </ul>

     
      
      <Footer />
      </div>
      
      
    );
}

    export default Noticias;

  