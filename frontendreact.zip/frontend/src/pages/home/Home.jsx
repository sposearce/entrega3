// imports
import React from 'react';

import Logo from '../../images/logo.png';
import Footer from '../../common/Footer';
import './Home.css';
import NavBar from '../../components/NavBar';
import Cards from '../../components/Cards';



// component (function)
const Home = () => {
  const text = 'BIENVENIDOS A SPA BROKERS DE REASEGUROS';
  return (
    <>
   
      
      <h1>{text}</h1>
      <h3>PRIMERA WEB DE SEGUROS EN REACT</h3>
      
      <Cards />
      
      <Footer />
    </>
  );
}

// export
export default Home;
