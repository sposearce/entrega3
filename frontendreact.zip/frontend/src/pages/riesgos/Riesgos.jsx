import React from "react";
import Footer from "../../common/Footer";

const Riesgos = () => {
   

    return (
        <>
   <div>
      
      <div>

      <h2>Riesgos</h2>
      <br></br>
    <p>Nos especializacon en los siguientes riesgos:</p>
    <br></br>
    <span>
        <ul>Property</ul>
        <ul>Energy</ul>
        <ul>RC</ul>
        <ul>Todo Riesgo</ul>
        <ul>Fine Arts</ul>
        <ul>Otros</ul>
    </span>
      </div>
      </div>
      <Footer />
    </>

    )
}

    export default Riesgos;