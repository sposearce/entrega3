import React from "react";
import Footer from '../../common/Footer';

const Servicios = () => {


    const text = 'pagina servicios';

    return (
        <>
   
      
      <h2>{text}</h2>
      
     
      
      <Footer />
    </>

    )
}

    export default Servicios;