import React from 'react';
import { Link } from 'react-router-dom';
import Img404 from '../../images/404.jpg';


import routePaths from '../../routePaths';
import './NotFound.css'

const NotFound = () => {
  return (
        <div className="notFound">
      <span className="notFoundText">Prueba 404 Not Found</span>
      <img src={Img404} alt="404" />
      <Link to={routePaths.home} className="notFoundLink">
        Volver a Intro
      </Link>
    </div>
  )
};

export default NotFound;
