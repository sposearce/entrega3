import logo from './images/logochico.jpg';
import './App.css';
import RoutesApp from './RoutesApp';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p className="titulo1">
          BIENVENIDOS A SPA BROKERS DE REASEGUROS
        </p>
        <a> Primer Broker de Reaseguros en REACT </a>
      </header>
        {/* <RoutesApp /> */}
            </div>
      );     
}

export default App;