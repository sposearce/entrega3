import React from "react";
import Footer from '../../common/Footer';

const SPA = () => {


    const text = 'pagina SPA';

    return (
        <>
   
      
      <h2>{text}</h2>
      
     
      
      <Footer />
    </>

    )
}

    export default SPA;