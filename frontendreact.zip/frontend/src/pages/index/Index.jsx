// imports
import React from 'react';

import Foto from '../../images/bolamundo.jpg';
import Footer from '../../common/Footer';
import './Index.css';
import NavBar from '../../components/NavBar';




// component (function)




const Index = () => {
  const text = 'pagina 2 ';
  return (
    <div>

   
    
   
<h2>SPA Brokers</h2>
    <p>Somos un broker de seguros y reaseguros, enfocados en las necesidades de un mercado diverso, obteniendo los mejores costos y coberturas del mercado.</p>
      
      <img src={Foto} alt="fotomundo" />

    
      <Footer />
    
    </div>
  );
}

// export
export default Index;
