import React from 'react';

import './App.css';
import RoutesApp from './RoutesApp';
import { BrowserRouter as Router } from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './pages/home/Home';
import Index from './pages/index/Index';
import Noticias from './pages/noticias/Noticias';
import Riesgos from './pages/riesgos/Riesgos';
import Footer from './common/Footer';

// import Servicios from './pages/Servicios/Servicios';
// import SPA from './pages/SpaBrokers/SPA';

import Logo2 from '../src/images/logo.png';


function App() {
  return (
    
    <div className="App">
      <NavBar />

      
      <img  src={Logo2} alt="logospa" />

       



      <RoutesApp />
      
      <Footer />

    </div>
  );
}

export default App;
