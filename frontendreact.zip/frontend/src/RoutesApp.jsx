import React from 'react';
import { Routes, Route } from 'react-router-dom';

import routePaths from './routePaths';
import Home from './pages/home/Home';
import Index from './pages/index/Index';

import NotFound from './pages/not-found/NotFound';

import Noticias from './pages/noticias/Noticias';
import Riesgos from './pages/riesgos/Riesgos';



const RoutesApp = () => {
  return (
    <>
      <Routes>
        <Route path={routePaths.home} element={<Home />} />
        <Route path={routePaths.index} element={<Index />} />
       
        
        <Route path={routePaths.noticias} element={<Noticias />} />
        <Route path={routePaths.riesgos} element={<Riesgos />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default RoutesApp;
