const routePaths = {
  home: '/',
  index: 'index',
  counter: '/counter',
  tasks: '/task-list',
  product: '/product/:productId',
  treeImage: '/tree-image',
  noticias: '/noticias',
  riesgos: '/riesgos',
  
}

export default routePaths;