import React from 'react';
import '../common/Footer.css';

const Footer = () => {
  return (
    
    <div className='footer'>

    <div className='aaa' >
    <h3> SPA BROKERS DE REASEGUROS  </h3>
         
    </div>
<div>
<h4 className ='bbb' href="">CONSULTAS</h4> 
<div class="address-content"><a href="mailto:info@spabrokers.com">info@spabrokers.com</a></div>

</div>
    
<div class="address-box"> 
        <h3>SEDE CENTRAL</h3>
           <div class="address-contact">
              <span class="fa-stack"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-map-marker fa-stack-1x fa-inverse"></i></span>
          <div class="address-content"> 18 de Diciembre 123 piso 21.  Montevideo, Uruguay. </div>
    </div>
                
    <div class="address-contact">
        <span class="fa-stack"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-phone fa-stack-1x fa-inverse"></i></span>
        <div class="address-content">(+589) 2618-6100 | 0800 SPA (772)</div>
    </div>

     <div class="address-contact">
        <span class="fa-stack"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-envelope-o fa-stack-1x fa-inverse"></i></span>
        {/* <div class="address-content"><a href="mailto:info@spabrokers.com">info@spabrokers.com</a></div> */}
    </div>

                        </div>
    
    </div>
  )
};

export default Footer
