// import React from 'react';
// import { Link } from "react-router-dom";
// import Logo2 from '../images/logo.png';
// import Time from "./Time";
// import '../components/NavBar.css';



//  /* <h1 class='logo'>{ <Link to='/'>
//              <img src={Logo2} ></img> 
//              </Link> } </h1> */


// const Header = () => {

//     return (

//       <div class="position-relative">
//   <div class="position-absolute top translate-middle">
             
//                     <nav className="navbar navbar-expand-lg navbar-light bg-light">
//                       <div className="container-fluid">
//                        <a className="navbar-brand" href="#"></a>
//                 <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
//                   <span className="navbar-toggler-icon"></span>
//                 </button>
//                 <div className="collapse navbar-collapse" id="navbarNav">
//                   <ul className="navbar-nav">
//                     <li className="nav-item">
//                     <Link className="nav-link active"  to='/' > Home</Link>
//                     </li>
//                     <li>
//                     <Link className="nav-link active"  to='index' > Inicio</Link>
//                     {/* con el link defino el acceso que le quiero dar */}
//                     </li>
//                     <li>
//                     <a className="nav-link" href="#">Login</a>
//                     </li>
//                     <li>
//                     <a className="nav-link disabled">Nosotros</a>
//                     </li>
//                     <li>
//                     <a className="nav-link disabled">Contacto</a>
//                     </li>
//                     <li>
//                     <a className="nav-link disabled"><Time/> </a>
//                     </li>
//                   </ul>
//                 </div>
//               </div>
//             </nav>
//             </div>
//       </div>
      

//     )
//     }





// export default Header;
