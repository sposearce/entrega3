import React from 'react';
// import logo from './logo.svg';
import './Time.css';




class Time extends React.Component {
  state={
    curTime : new Date().toLocaleString(),
  }
  render(){
    return (
      <div className="Time">
        <h4> Montevideo, Uruguay : {this.state.curTime}</h4>
      </div>
    );
  }
}

export default Time;