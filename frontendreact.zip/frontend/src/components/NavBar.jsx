import React from "react";
// import React, { useContext } from "react";
import { Link } from "react-router-dom";
import Logo2 from '../images/logo.png';
import Time from "./Time";
import "./NavBar.css"




// import '../components/NavBar.css';



 /* <h1 class='logo'>{ <Link to='/'>
             <img src={Logo2} ></img> 
             </Link> } </h1> */


const navbar = () => {

      return (
      

      <div className="aaa">
                    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                      <div className="container-fluid">

                       {/* <a className="navbar-brand" href="#">Navbar</a> */}
                      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                      </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                  <h2 className="aaaa">
                    
                    <ul className="navbar-nav mx-auto">
          

                    <li className="nav-item">
                    <Link className="nav-link active"  to='/' > Inicio</Link>
                    </li>
                    <li>
                    <Link className="nav-link active"  to='index' > SPA Brokers</Link>
                    {/* con el link defino el acceso que le quiero dar */}
                    </li>
                    <li>
                    <Link className="nav-link active" to='404'>Servicios</Link>
                    </li>
                    <li>
                    <Link className="nav-link active" to='/riesgos'>Riesgos</Link>
                    </li>
                    <li>
                    <Link className="nav-link active" to='/noticias'> Noticias</Link>
                    </li>
                    <li>
                    <a className="nav-link active"  href=".\pages\Login\login.html" > LOGIN </a>
                    </li>
                  
                    <li>
                      
                    
                    
                    </li>
                  </ul>
                  
                  </h2>
                 
                </div>
                <h2 className="nav-link active"><Time/> </h2>
              </div>
            </nav>
            </div>
    

    )
    }

export default navbar;




