import React from "react";
import '../components/Cards.css';
import { Link } from "react-router-dom";

const Cards = () => {

    return (
     
<div class="container"> 

<div class="row">
  
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">SPA Brokers</h5>
        <p class="card-text">Conozca nuestra historia.</p>
        <Link to='index' class="btn btn-primary">Ir</Link>
      </div>
    </div>
  </div>

  
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Servicios</h5>
        <p class="card-text">Colocaciones de riesgos complejos en mercados internacionales.</p>
        <Link to="/servicios" class="btn btn-primary">Ir</Link>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Riesgos</h5>
        <p class="card-text">Especializacion en Riesgos complejos.</p>
        <Link to='/riesgos' class="btn btn-primary">Ir</Link>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Noticas</h5>
        <p class="card-text">Noticias del Mundo del Seguro.</p>
        <Link to='/noticias' class="btn btn-primary">Ir</Link>
      </div>
    </div>
  </div>
  
</div>
</div>



    )
}
export default Cards;